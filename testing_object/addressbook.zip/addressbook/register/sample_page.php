<? 
//Set permission level threshold for this page remove if page is good for all levels
$permission_level=1;

include"auth_check_header.php";

?>	

<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />
<title>AMS Agent Index</title>
</head>

<body topmargin="0">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top"><div align="center">
      <p>&nbsp;</p>
      <p><strong><font size="3"><font size="5" face="Trebuchet MS">Sample Page</font>
          </font><font face="Trebuchet MS"></font></font></strong>        </p>
      <p><font face="Trebuchet MS"><strong><font size="3">You are logged in and can see content for which you are authorized </font></strong></font></p>
    <p><font face="Trebuchet MS"><a href="logout.php">Log out </a></font><a href="logout.php"></a></p>
    </div>
    </td>
  </tr>
</table>
<br>
<A href="http://www.amsmerchant.com" target="_blank"></A><br>
<br>
</body>
</html>
