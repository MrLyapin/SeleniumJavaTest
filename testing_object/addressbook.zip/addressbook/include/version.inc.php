<?php
/*
 * Version definition file.
 *
 * - $LastChangedDate$
 * - $Rev$
 */

$revision = '$Format:%H$';
$revision = str_replace('$', '', str_replace(' ', '', str_replace('Rev: ', '', $revision)));
$version = '8.1.15'.' - r'.$revision.'@github';
?><?php $version = '8.2.5'; ?> 
